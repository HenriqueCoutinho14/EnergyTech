<?php
function conectar()
{
    $usuario = 'root';
    $senha = '123456';
    try {
        $conn = new PDO('mysql:host=localhost;dbname=feira', $usuario, $senha);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return null;
    }
}

function listarSalas($nome_sala)
{
    $conn = conectar();
    if (!$conn) return null;

    try {
        $query = "SELECT salas.idsalas, salas.nome_sala, blocos.nome_bloco
                  FROM salas
                  JOIN blocos ON salas.idbloco = blocos.idblocos
                  WHERE salas.nome_sala = :nome_sala";
                  
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':nome_sala', $nome_sala);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return null;
    }
}

function listarBlocos()
{
    $conn = conectar();
    if (!$conn) return null;

    try {
        $stmt = $conn->prepare("SELECT * FROM blocos");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return null;
    }
}
//refeito 12/11/2024
function cadastrarReserva($idbloco, $idsala, $data_reserva, $hora_inicio, $hora_fim) {
    try {
        $conn = conectar(); // Sua função de conexão com o banco
        if (!$conn) {
            throw new Exception("Erro ao conectar ao banco de dados.");
        }

        // Insere a reserva no banco
        $stmt = $conn->prepare("INSERT INTO reserva (idbloco, idsala, data_reserva, inicio_reserva, fim_reserva) 
                                VALUES (:idbloco, :idsala, :data_reserva, :inicio_reserva, :fim_reserva)");

        // Vincula os parâmetros à consulta
        $stmt->bindParam(':idbloco', $idbloco);
        $stmt->bindParam(':idsala', $idsala);
        $stmt->bindParam(':data_reserva', $data_reserva);
        $stmt->bindParam(':inicio_reserva', $hora_inicio);
        $stmt->bindParam(':fim_reserva', $hora_fim);

        // Executa a inserção
        if ($stmt->execute()) {
            return true; // Reserva cadastrada com sucesso
        } else {
            return false; // Falha na inserção
        }
    } catch (PDOException $e) {
        echo "Erro ao cadastrar reserva: " . $e->getMessage();
        return false; // Erro de banco
    }
}



function cadastrarConsumo($idreserva, $ar, $lampada, $quantidade)
{
    $conn = conectar();
    if (!$conn) return null;

    try {
        $stmt = $conn->prepare("INSERT INTO consumo(idreserva, ar, lampada, quantidade)
                                VALUES (:idreserva,  :ar, :lampada, :quantidade)");
        $stmt->bindParam(':idreserva', $idreserva);
        $stmt->bindParam(':ar', $ar);
        $stmt->bindParam(':lampada', $lampada);
        $stmt->bindParam(':quantidade', $quantidade);

        return $stmt->execute();
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return false;
    }
}

function mostraConsumo()
{
    // Estabelece a conexão com o banco de dados
    $conn = conectar();
    if (!$conn) {
        echo "Erro: Falha ao conectar com o banco de dados.";
        return null;
    }

    try {
        // Prepara a consulta SQL para buscar os dados necessários
        $stmt = $conn->prepare("SELECT idreserva, ar, lampada, quantidade
                                FROM consumo");
        
        // Executa a consulta
        $stmt->execute();
        
        // Verifica se há resultados e os retorna; caso contrário, exibe uma mensagem
        $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
       
        
        return $resultados;

    } catch (PDOException $e) {
        // Exibe uma mensagem de erro detalhada em caso de exceção
        echo "Erro na consulta ao banco de dados: " . $e->getMessage();
        return null;
    }
}



function cadastrarUsuario($nome, $senha)
{
    $conn = conectar();
    if (!$conn) return null;

    try {
        $stmt = $conn->prepare("INSERT INTO usuario(nome, senha) VALUES (:nome, :senha)");
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':senha', $senha);
        return $stmt->execute();
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return false;
    }
}

function excluirUsuario($idusuario)
{
    $conn = conectar();
    if (!$conn) return null;

    try {
        $stmt = $conn->prepare("DELETE FROM usuario WHERE idusuario = :idusuario");
        $stmt->bindParam(':idusuario', $idusuario, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return false;
    }
}

function buscarSalasPorBloco($idbloco)
{
    $conn = conectar();
    if (!$conn) return null;

    try {
        $stmt = $conn->prepare("SELECT idsalas, nome_sala FROM salas WHERE idbloco = :idbloco");
        $stmt->bindParam(':idbloco', $idbloco, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return null;
    }
}

function reservas() {
    $conn = conectar();
    if (!$conn) return null;

    try {
        $query = "SELECT reserva.idreserva, reserva.data_reserva, reserva.inicio_reserva, reserva.fim_reserva,
                         blocos.nome_bloco, salas.nome_sala
                  FROM reserva
                  JOIN blocos ON reserva.idbloco = blocos.idbloco
                  JOIN salas ON reserva.idsala = salas.idsala";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return null;
    }
}



function excluirReserva($idreservas)
{
    $conn = conectar();
    if (!$conn) return false;

    try {
        $stmt = $conn->prepare("DELETE FROM reservas WHERE idreservas = :idreservas");
        $stmt->bindParam(':idreservas', $idreservas, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return false;
    }
}

function dadosArduino(){
    $conn = conectar();
    if (!$conn) return null;

    try {
        $stmt = $conn->prepare("SELECT chave1,chave2,chave3,chave4 FROM chaves ORDER BY id DESC LIMIT 1");
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
        return null;
    }
}

function mostraUsuario(){

    $conn = conectar();
    if (!$conn) return null;

    try {
        $query = "SELECT idusuario, nome, senha from usuario";
        $stmt = $conn->prepare($query);
        $stmt->execute();
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
    echo 'ERROR: ' . $e->getMessage();
    return null;
}
}

?>
