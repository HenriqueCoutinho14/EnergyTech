<?php
include 'banco.php';

if (isset($_GET['id_bloco'])) {
    $id_bloco = intval($_GET['id_bloco']);
    
    // Supondo que a função `buscarSalasPorBloco` seja implementada no banco.php
    $salas = buscarSalasPorBloco($id_bloco);

    echo json_encode($salas);
}
?>
