<?php
include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';

// Verifica se o formulário de cadastro de reserva foi enviado
if (isset($_POST['data_reserva'], $_POST['id_bloco'], $_POST['idsala'], $_POST['inicio_reserva'], $_POST['fim_reserva'])) {

    // Extraímos os valores do formulário
    $idbloco = $_POST['id_bloco'];
    $idsala = $_POST['idsala'];
    $data_reserva = $_POST['data_reserva'];
    $hora_inicio = $_POST['inicio_reserva'];
    $hora_fim = $_POST['fim_reserva'];

    // Verifica se a sala já está reservada para a data e horário fornecidos
    try {
        $conn = conectar();
        if (!$conn) {
            echo json_encode(["status" => "erro", "message" => "Erro ao conectar ao banco de dados."]);
            exit();
        }

        // Consulta para verificar conflito de horários
        $stmt = $conn->prepare("SELECT COUNT(*) FROM reserva 
                                WHERE idbloco = :id_bloco
                                  AND idsala = :idsala
                                  AND data_reserva = :data_reserva
                                  AND ((inicio_reserva < :fim_reserva AND fim_reserva > :inicio_reserva))");

        // Bind dos parâmetros para a verificação
        $stmt->bindParam(':id_bloco', $idbloco, PDO::PARAM_INT);
        $stmt->bindParam(':idsala', $idsala, PDO::PARAM_INT);
        $stmt->bindParam(':data_reserva', $data_reserva, PDO::PARAM_STR);
        $stmt->bindParam(':inicio_reserva', $hora_inicio, PDO::PARAM_STR);
        $stmt->bindParam(':fim_reserva', $hora_fim, PDO::PARAM_STR);
        $stmt->execute();

        // Se já existir uma reserva, retorna erro
        if ($stmt->fetchColumn() > 0) {
            echo json_encode(["status" => "erro", "message" => "Sala já reservada para o horário selecionado."]);
            header("Location: \feira\ENERGY_TECH\projeto_\Reserva.php");
            Exit();
            exit();
        }

        // Caso não haja conflito, insere a nova reserva
        if (cadastrarReserva($idbloco, $idsala, $data_reserva, $hora_inicio, $hora_fim)) {
            // Use o caminho correto, verificando a existência do arquivo
            header("Location: /feira/ENERGY_TECH/consumo/index.php");
            exit();
        } else {
            echo json_encode(["status" => "erro", "message" => "Erro ao cadastrar a reserva."]);
        }

    } catch (PDOException $e) {
        echo json_encode(["status" => "erro", "message" => "Erro ao conectar ao banco de dados: " . $e->getMessage()]);
    }

} elseif (isset($_POST['registro'], $_POST['btu'], $_POST['lampada'], $_POST['quantidade_lampadas'])) {

    // Verifica se os campos de consumo estão preenchidos
    $id_reserva = $_POST['registro'];
    $ar = $_POST['btu'];
    $lampada = $_POST['lampada'];
    $quantidade = $_POST['quantidade_lampadas'];

    // Função para registrar o consumo
    if (cadastrarConsumo($id_reserva, $ar, $lampada, $quantidade)) {
        echo json_encode(["status" => "sucesso", "message" => "Consumo registrado com sucesso."]);
        header("Location: /feira/ENERGY_TECH/projeto__/Relatorios.php");
            exit();
    } else {
        echo json_encode(["status" => "erro", "message" => "Erro ao registrar o consumo."]);
    }

} elseif (isset($_POST["nome"], $_POST["senha"])) {

    // Verifica se os campos do usuário estão preenchidos
    $nome = $_POST["nome"];
    $senha = $_POST["senha"];

    if (cadastrarUsuario($nome, $senha)) {
        echo json_encode(["status" => "sucesso", "message" => "Usuário cadastrado com sucesso."]);
        header("Location: /feira/ENERGY_TECH/registra/registra.php");
        Exit();
    } else {
        echo json_encode(["status" => "erro", "message" => "Erro ao cadastrar usuário."]);
    }

} else {
    echo json_encode(["status" => "erro", "message" => "Por favor, preencha todos os campos obrigatórios."]);
}

// Função para excluir reserva ou usuário (centralizada para evitar duplicação de código)
function excluir($tipo, $id) {
    if ($tipo === 'reserva') {
        if (excluirReserva($id)) {
            echo "<script>alert('Reserva excluída com sucesso!');</script>";
            echo "<script>window.location.href = 'reservas.php';</script>";
        } else {
            echo "<script>alert('Erro ao excluir a reserva!');</script>";
        }
    } elseif ($tipo === 'usuario') {
        if (excluirUsuario($id)) {
            echo "<script>alert('Usuário excluído com sucesso!');</script>";
            echo "<script>window.location.href = 'usuarios.php';</script>";
        } else {
            echo "<h1>Erro ao excluir usuário.</h1>";
        }
    }
}

// Checa se existe uma solicitação para excluir reserva ou usuário
if (isset($_GET['excluir_id'])) {
    $excluir_id = $_GET['excluir_id'];
    $tipo = isset($_GET['tipo']) ? $_GET['tipo'] : '';  // Identifica se é reserva ou usuário

    if ($tipo === 'reserva') {
        excluir('reserva', $excluir_id);
    } elseif ($tipo === 'usuario') {
        excluir('usuario', $excluir_id);
    } else {
        echo "<h1>Tipo de exclusão inválido.</h1>";
    }
}
?>
