<?php
$nome = isset($_GET['nome']) ? $_GET['nome'] : '';

if ($nome) {
    $socorro = $pdo->prepare('SELECT luz, ar_condicionado FROM salas WHERE nome = ?');
    $socorro->execute([$nome]);
    $sala = $socorro->fetch();

    if ($sala) {
        ?>
        <h1><?php echo htmlspecialchars($nome); ?></h1>
        <p>Luz: <?php echo htmlspecialchars($sala['luz']); ?></p>
        <p>Ar Condicionado: <?php echo htmlspecialchars($sala['ar_condicionado']); ?></p>
        
        <form method="post" action="">
            <label>De quantos BTUs o ar-condicionado que você tem na sala?</label><br>
            <select name="btu">
                <option value="15.7">7.500 (15,7 kW)</option>
                <option value="17.1">9.000 (17,1 kW)</option>
                <option value="20.2">10.000 (20,2 kW)</option>
                <option value="22.7">12.000 (22,7 kW)</option>
                <option value="38.6">24.000 (38,6 kW)</option>
                <option value="54.1">30.000 (54,1 kW)</option>
                <option value="61.3">36.000 (61,3 kW)</option>
                <option value="89.3">48.000 (89,3 kW)</option>
                <option value="104.4">60.000 (104,4 kW)</option>
            </select><br><br>

            <label>Qual seu tipo de lâmpada?</label><br>
            <select name="lampada">
                <option value="0.06">Lâmpada de Baixo Consumo:0 6 watts (0.06 kW)</option>
                <option value="0.042">Lâmpada Incandescente: 42 watts (0.042 kW)</option>
                <option value="0.012">Lâmpada de Halógeno: 12 watts (0.012 kW)</option>
                <option value="0.014">Lâmpada LED: 14 watts (0.014 kW)</option>
            </select><br><br>

            <label>Quantas lâmpadas você tem na sala?</label><br>
            <select name="quantidade_lampadas">
                <?php for ($i = 1; $i <= 8; $i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
            </select><br><br>

            <input type="submit" value="Calcular Consumo">
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $btu = $_POST['btu'];
            $lampada = $_POST['lampada'];
            $quantidade_lampadas = $_POST['quantidade_lampadas'];

            $consumo_lampadas = $lampada * $quantidade_lampadas;
            $consumo_total = $btu + $consumo_lampadas;

            echo "<h2>Consumo Total:</h2>";
            echo "<p>Ar Condicionado: " . htmlspecialchars($btu) . " kW</p>";
            echo "<p>Lâmpadas: " . htmlspecialchars($consumo_lampadas) . " kW</p>";
            echo "<p>Consumo Total: " . htmlspecialchars($consumo_total) . " kW</p>";
        }
        ?>

       

        <a href="?page=salas">Voltar para Salas</a>
        <?php
    } else {
        echo '<h1>Sala não encontrada.</h1>';
    }
} else {
    echo '<h1>Nenhuma sala selecionada.</h1>';
}
?>
