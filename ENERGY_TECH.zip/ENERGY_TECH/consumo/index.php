<?php

include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';


?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consumo - ENERGY TECH</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="/feira/ENERGY_TECH/img/aguia.png" type="image/png">

</head>

<body>
    <header class="navbar">
        <div class="logo" onclick="menu()">
            <div class="logo-text"><img src="/feira/ENERGY_TECH/img/aguia.png" width="35px"></div>
        </div>

        <h1>ENERGY TECH</h1>
        <div class="user-menu">
            <button class="user-button" onclick="toggleMenu()">Nome do Usuário ▼</button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="/feira/ENERGY_TECH/login/login.php" onclick="logout()">Sair</a>
                <a onclick="ajuda()">Ajuda</a>
            </div>
        </div>
    </header>

    <div id="reservation-screen" class="screen">
        <h2 class="reserva">REGISTRAR CONSUMO</h2>

        <form class="form" action="\feira\ENERGY_TECH\database\processa_dados.php" method="post">
            <div class="form-row">
                <div class="col">
                    <label for="input1">ID_Reserva</label>
                    <?php
                  echo  "<select name='registro'>";
    
                $ver = reservas();
                foreach ($ver as $i) {
                echo "<option>" .htmlspecialchars($i['idreserva']) . "</option>";
            }
             echo"  </select>";
                ?>
                </div>
                <div class="col">
                    <label for="input3">Ar-Condicionado</label>
                    <select type="number" name="btu" require>
                        <option value="15.7">7.500 (15,7 kW)</option>
                        <option value="17.1">9.000 (17,1 kW)</option>
                        <option value="20.2">10.000 (20,2 kW)</option>
                        <option value="22.7">12.000 (22,7 kW)</option>
                        <option value="38.6">24.000 (38,6 kW)</option>
                        <option value="54.1">30.000 (54,1 kW)</option>
                        <option value="61.3">36.000 (61,3 kW)</option>
                        <option value="89.3">48.000 (89,3 kW)</option>
                        <option value="104.4">60.000 (104,4 kW)</option>
                    </select>
                        <!-- opções -->
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="col">
                    <label for="input4">Tipo de Lâmpada</label>
                    <select type="text" name="lampada" require>
                        <option value="0.06">Lâmpada de Baixo Consumo:0 6 watts (0.06 kW)</option>
                        <option value="0.042">Lâmpada Incandescente: 42 watts (0.042 kW)</option>
                        <option value="0.012">Lâmpada de Halógeno: 12 watts (0.012 kW)</option>
                        <option value="0.014">Lâmpada LED: 14 watts (0.014 kW)</option>
                    </select>
                        <!-- opções -->
                    </select>
                </div>
                <div class="col">
                    <label for="input5">Quantidade de Lampadas</label>
                    <select type="number" name="quantidade_lampadas" require>
                <?php for ($i = 1; $i <= 8; $i++): ?>
                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                <?php endfor; ?>
            </select>
                </div>
                
            </div>

            <button type="submit" class="reserve-button">REGISTRAR</button>
        </form>

        <!-- Tabela Abaixo do Formulário -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>id_Reserva</th>
                        <th>Ar</th>
                        <th>Lâmpada</th>
                        <th>Quantidade</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <!-- Linhas de dados da tabela -->
                    <?php
                    $mostra = mostraConsumo();
         foreach ($mostra as $i) {  
             echo "<tr>";
             
          echo "<td>". htmlspecialchars($i['idreserva']) ."</td>";
           echo "<td>". htmlspecialchars($i['ar']) ."</td>";
            echo "<td>". htmlspecialchars($i['lampada']) ."</td>";
             echo "<td>". htmlspecialchars($i['quantidade']) ."</td>";
             "</tr>";}
         
          ?>
                </tbody>
                </table>
        </div>


        <script>
            function toggleMenu() {
                const dropdown = document.getElementById("dropdownMenu");
                dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            }

            function logout() {
                alert("Você saiu do sistema.");
            }
            function ajuda() {
            window.location.href = "/feira/ENERGY_TECH/ajuda/index.php"
        }

            function menu() {
                window.location.href = "/feira/ENERGY_TECH/dashbord_admin/admin.php"
            }
            function mostrarNomeUsuario() {
            const nomeUsuario = localStorage.getItem("nomeUsuario");
            if (nomeUsuario) {
                document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
            }
        }

        // Chame a função ao carregar a página
        mostrarNomeUsuario();
        </script>
</body>

</html>