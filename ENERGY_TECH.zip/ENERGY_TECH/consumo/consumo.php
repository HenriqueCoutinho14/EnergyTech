<?php
include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';




$btu = $_POST['btu'];
$lampada = $_POST['lampada'];
$quantidade_lampadas = $_POST['quantidade_lampadas'];;






  calcular($btu, $lampada, $quantidade_lampadas)
            
        ?>