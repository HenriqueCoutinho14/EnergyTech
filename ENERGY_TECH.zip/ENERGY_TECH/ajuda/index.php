<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajuda - ENERGY TECH</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="/feira/ENERGY_TECH//img/aguia.png" type="image/png">

</head>

<body>
    <header class="navbar">
        <div class="logo" onclick="menu()">
            <div class="logo-text"><img src="/feira/ENERGY_TECH/img/aguia.png" width="35px"></div>
        </div>

        <h1>ENERGY TECH</h1>
        <div class="user-menu">
            <button class="user-button" onclick="toggleMenu()">Nome do Usuário ▼</button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="/feira/ENERGY_TECH//login/loginn.php" onclick="logout()">Sair</a>
                <a href="#">Ajuda</a>
            </div>
        </div>
    </header>

    <div id="reservation-screen" class="screen">
        

        <div class="form">
            <h1>MANUAL DE INSTRUÇÔES</h1>
            <p>Nosso sistema visualiza o fucionamento de um monitoramento de energia em salas de aulas, e <br>
                simula o consumo de energia. </p>

            <p><strong>Monitoramento</strong> - A aba de monitoramento funciona da seguinte forma, contem dois blocos. <br>
                A e B, onde cada bloco tem duas salas. <br>
                e nestas salas vão ter um sistema de luzes, onde vão simular sensores de alerta, exemplo: <br>
                <span class="verde">Luz Verde</span>: Ligada <br>
                <span class="laranja">Luz Laranja</span>: Alerta (fora do horario) <br>
                <span class="cinza">Luz Cinza</span>: Desligada
            </p>


            <p></p>


            <p><strong>Reserva</strong> - A aba de reserva ira registrar uma sala de aula que voce podera determinar a data e o horario.
                <br>
                E tambem podera excluir e editar uma reserva ja realizada.
            </p>

            <p></p>


            <p><strong>Consumo</strong> - A aba de consumo ira simular o consumo de energia em determinada sala. </p>
            <p>Para dúvidas adicionais, contate o suporte <strong>9999-9999</strong>.</p>
        </div>





        <script>
            function toggleMenu() {
                const dropdown = document.getElementById("dropdownMenu");
                dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            }

            function logout() {
                alert("Você saiu do sistema.");
            }

            function menu() {
                window.location.href = "/feira/ENERGY_TECH//dashbord_admin/admin.php"
            }
            function ajuda() {
            window.location.href = "/feira/ENERGY_TECH//ajuda/index.php"
        }
            function mostrarNomeUsuario() {
                const nomeUsuario = localStorage.getItem("nomeUsuario");
                if (nomeUsuario) {
                    document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
                }
            }

            // Chame a função ao carregar a página
            mostrarNomeUsuario();
        </script>
</body>

</html>