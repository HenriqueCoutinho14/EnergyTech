<?php
include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';

// Recebe o ID do bloco via GET
$id_bloco = isset($_GET['id_bloco']) ? (int)$_GET['id_bloco'] : 0;

// Consulta as salas do bloco selecionado
$sql = "SELECT * FROM sala WHERE idbloco = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id_bloco]);

// Obtém os resultados
$salas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Retorna as salas como JSON
echo json_encode($salas);
?>
