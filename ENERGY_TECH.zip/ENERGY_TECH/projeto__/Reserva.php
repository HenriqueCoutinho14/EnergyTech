<?php
include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';  // Conexão com o banco
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva - ENERGY TECH</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="/feira/ENERGY_TECH/img/aguia.png" type="image/png">
</head>

<body>
    <header class="navbar">
        <div class="logo" onclick="menu()">
            <div class="logo-text"><img src="/feira/ENERGY_TECH/img/aguia.png" width="35px"></div>
        </div>

        <h1>ENERGY TECH</h1>
        <div class="user-menu">
            <button class="user-button" onclick="toggleMenu()">Nome do Usuário ▼</button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="/feira/ENERGY_TECH/login/loginn.php" onclick="logout()">Sair</a>
                <a onclick="ajuda()">Ajuda</a>
            </div>
        </div>
    </header>

    <div id="reservation-screen" class="screen">
        <h2 class="reserva">RESERVAR</h2>

        <form id="reservaForm" action="/feira/ENERGY_TECH/database/processa_dados.php" method="post" class="form" >
            <div class="form-row">
                <div class="col">
                    <label for="input0">Bloco</label>
                    <select id="input0" name="id_bloco" onchange="atualizarSalas(this.value)">
                        <option value="1">Bloco A</option>
                        <option value="2">Bloco B</option>
                    </select>
                </div>

                <div class="col">
                    <label for="input1">Sala</label>
                    <select id="input1" name="idsala">
                        <option value="1">Sala-A1</option>
                        <option value="2">Sala-A2</option>
                        <option value="3">Sala-B1</option>
                        <option value="4">Sala-B2</option>
                    </select>
                </div>

                <div class="col">
                    <label for="input3">Data</label>
                    <input type="date" id="input3" name="data_reserva" required>
                </div>
            </div>

            <div class="form-row">
                <div class="col">
                    <label for="input4">Hora Início</label>
                    <input type="time" id="input4" name="inicio_reserva" required>
                </div>
                <div class="col">
                    <label for="input5">Hora Fim</label>
                    <input type="time" id="input5" name="fim_reserva" required>
                </div>
            </div>

            <button type="submit" class="reserve-button">Reservar</button>
        </form>
    </div>

    <div class="table-container">
        <?php 
        // Exibe as reservas cadastradas
        $reservas = reservas();

    echo "<table class='table'>
            <thead>
                <tr>
                    <th>ID Reserva</th>
                    <th>Bloco</th>
                    <th>Sala</th>
                    <th>Data</th>
                    <th>Hora Início</th>
                    <th>Hora Fim</th>
                </tr>
            </thead>
            <tbody>";

    foreach ($reservas as $reserva) {
        echo "<tr>
                <td>" . htmlspecialchars($reserva['idreserva']) . "</td>
                <td>" . htmlspecialchars($reserva['nome_bloco']) . "</td>
                <td>" . htmlspecialchars($reserva['nome_sala']) . "</td>
                <td>" . htmlspecialchars($reserva['data_reserva']) . "</td>
                <td>" . htmlspecialchars($reserva['inicio_reserva']) . "</td>
                <td>" . htmlspecialchars($reserva['fim_reserva']) . "</td>
              </tr>";
    }

    echo "</tbody></table>";

?>
    </div>

    <script>
        function toggleMenu() {
            const dropdown = document.getElementById("dropdownMenu");
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
        }

        function ajuda() {
            window.location.href = "/feira/ENERGY_TECH/ajuda/index.php";
        }

        function logout() {
            alert("Você saiu do sistema.");
        }

        function menu() {
            window.location.href = "/feira/ENERGY_TECH/dashbord_admin/admin.php";
        }

        function mostrarNomeUsuario() {
            const nomeUsuario = localStorage.getItem("nomeUsuario");
            if (nomeUsuario) {
                document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
            }
        }

        // Função para fazer a reserva via AJAX
        function cadastrarReserva(event) {
    event.preventDefault(); // Evita o envio tradicional do formulário

    const formData = new FormData(document.getElementById("reservaForm"));

    fetch('/feira/ENERGY_TECH/database/processa_dados.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "erro") {
            alert(data.message);  // Exibe o erro
        } else if (data.status === "sucesso") {
            alert(data.message);  // Exibe a mensagem de sucesso
            location.reload(); // Atualiza a página para mostrar a nova reserva na tabela
        }
    })
    .catch(error => console.error('Erro ao enviar os dados:', error));
}


        // Função para atualizar as salas com base no bloco escolhido
        function atualizarSalas(idBloco) {
            fetch(`/feira/ENERGY_TECH/database/buscar_salas.php?id_bloco=${idBloco}`)
                .then(response => response.json())
                .then(data => {
                    const salaSelect = document.getElementById("input1");
                    salaSelect.innerHTML = ""; // Limpa as opções atuais

                    // Adiciona as novas opções baseadas nos dados retornados
                    data.forEach(sala => {
                        const option = document.createElement("option");
                        option.value = sala.idsala;
                        option.textContent = sala.nome_sala;
                        salaSelect.appendChild(option);
                    });
                })
                .catch(error => console.error("Erro ao buscar salas:", error));
        }

        // Chame a função ao carregar a página
        mostrarNomeUsuario();
    </script>
</body>

</html>
