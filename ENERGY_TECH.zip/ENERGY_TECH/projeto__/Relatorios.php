<?php
// Inclua o arquivo do banco de dados
include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';
  // Ajuste o nome do arquivo

// Chama a função que pega os dados de consumo
$consumos = mostraConsumo();  // Obtém os dados do consumo do banco
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Relatórios - ENERGY TECH</title>
  <link rel="stylesheet" href="styless.css">
  <link rel="icon" href="/feira/ENERGY_TECH/img/aguia.png" type="image/png">
</head>

<body>
  <header class="navbar">
    <div class="logo" onclick="menu()">
      <div class="logo-text"><img src="/feira/ENERGY_TECH/img/aguia.png" width="35px"></div>
    </div>

    <h1>ENERGY TECH</h1>
    <div class="user-menu">
      <button class="user-button" onclick="toggleMenu()">Nome do Usuário ▼</button>
      <div id="dropdownMenu" class="dropdown-content">
        <a href="/feira/ENERGY_TECH/login/loginn.php" onclick="logout()">Sair</a>
        <a onclick="ajuda()">Ajuda</a>
      </div>
    </div>
  </header>

  <h2 class="reserva">RELATÓRIOS</h2>
  <select class="seleto" id="blocoSelect" onchange="trocarBloco()">
    <option value="/feira/ENERGY_TECH/projeto__/Relatorios.php">RELATORIO</option>
    <option value="/feira/ENERGY_TECH/monitoramento/sala.php">BLOCO A</option>
    <option value="/feira/ENERGY_TECH/monitoramento/saladois.php">BLOCO B</option>
  </select>

  <div class="screen">
    <table>
      <thead>
        <tr>
          <th>ID_Reserva</th>

          <th>CONSUMO TOTAL (kWh)</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Verifica se há resultados e exibe
        if ($consumos) {
          foreach ($consumos as $consumo) {
            // Exibe as informações de cada linha
            echo "<tr>";
            echo "<td>" . htmlspecialchars($consumo['idreserva']) . "</td>";
            

            // Calcula o consumo total (supondo que 'ar' seja BTU e 'lampada' seja consumo por lâmpada)
            $consumo_total = $consumo['ar'] + ($consumo['lampada'] * $consumo['quantidade']);
            echo "<td>" . number_format($consumo_total, 2) . " kWh</td>"; // Exibe o consumo total formatado
            echo "</tr>";
          }
        } else {
          echo "<tr><td colspan='3'>Nenhum dado encontrado.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

  <script>
    function toggleMenu() {
      const dropdown = document.getElementById("dropdownMenu");
      dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    }

    function logout() {
      alert("Você saiu do sistema.");
    }

    function ajuda() {
      window.location.href = "/feira/ENERGY_TECH/ajuda/index.php";
    }

    function menu() {
      window.location.href = "/feira/ENERGY_TECH/dashbord_admin/admin.php";
    }

    function trocarBloco() {
      const select = document.getElementById("blocoSelect");
      const blocoUrl = select.value;
      window.location.href = blocoUrl;
    }

    function mostrarNomeUsuario() {
      const nomeUsuario = localStorage.getItem("nomeUsuario");
      if (nomeUsuario) {
        document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
      }
    }

    // Chama a função ao carregar a página
    mostrarNomeUsuario();
  </script>
  <script src="scripts.js"></script>
</body>

</html>
