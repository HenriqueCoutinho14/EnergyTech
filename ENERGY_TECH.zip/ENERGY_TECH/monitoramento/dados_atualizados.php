<?php

include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';

header('Content-Type: application/json');

// Definindo o fuso horário para Manaus (Amazonas)
date_default_timezone_set('America/Manaus');  // Ajuste o fuso horário para Manaus

try {
    $conn = conectar();
    if (!$conn) {
        echo json_encode(['error' => true, 'message' => 'Erro ao conectar ao banco de dados']);
        exit();
    }

    $dadosArduino = dadosArduino();
    if (!$dadosArduino) {
        echo json_encode(['error' => true, 'message' => 'Erro ao obter dados do Arduino']);
        exit();
    }

    // Função para verificar se a sala está reservada no momento
    function verificarReserva($idsala, $dataAtual, $horaAtual) {
        global $conn;
        
        $stmt = $conn->prepare("SELECT COUNT(*) FROM reserva 
                                WHERE idsala = :idsala 
                                AND data_reserva = :dataAtual 
                                AND :horaAtual BETWEEN inicio_reserva AND fim_reserva");
        $stmt->bindParam(':idsala', $idsala, PDO::PARAM_INT);
        $stmt->bindParam(':dataAtual', $dataAtual, PDO::PARAM_STR);
        $stmt->bindParam(':horaAtual', $horaAtual, PDO::PARAM_STR);
        $stmt->execute();
        
        return $stmt->fetchColumn() > 0;
    }

    // Data e hora atuais para verificar reservas ativas
    $dataAtual = date('Y-m-d');  // Obtém a data no formato correto (Y-m-d)
    $horaAtual = date('H:i:s');  // Obtém a hora no formato correto (H:i:s)

    // Verifica o estado de reserva para cada sala
    $reservado1 = verificarReserva(1, $dataAtual, $horaAtual);  // Para sala 1
    $reservado2 = verificarReserva(2, $dataAtual, $horaAtual);  // Para sala 2
    $reservado3 = verificarReserva(3, $dataAtual, $horaAtual);  // Para sala 3
    $reservado4 = verificarReserva(4, $dataAtual, $horaAtual);  // Para sala 4

    // Preparando resposta com os dados do Arduino e estado das reservas
    $response = [
        'chave1' => [
            'status' => $dadosArduino[0]['chave1'],
            'reserva' => $reservado1 ? 'Reservado' : 'Não Reservado'
        ],
        'chave2' => [
            'status' => $dadosArduino[0]['chave2'],
            'reserva' => $reservado2 ? 'Reservado' : 'Não Reservado'
        ],
        'chave3' => [
            'status' => $dadosArduino[0]['chave3'],
            'reserva' => $reservado3 ? 'Reservado' : 'Não Reservado'
        ],
        'chave4' => [
            'status' => $dadosArduino[0]['chave4'],
            'reserva' => $reservado4 ? 'Reservado' : 'Não Reservado'
        ],
    ];

    echo json_encode($response);

} catch (Exception $e) {
    echo json_encode(['error' => true, 'message' => 'Erro: ' . $e->getMessage()]);
}
?>
