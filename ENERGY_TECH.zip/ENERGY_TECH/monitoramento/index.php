<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoramento - ENERGY TECH</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="/feira/ENERGY_TECH/img/aguia.png" type="image/png">

</head>
<body>
    <header class="navbar">
        <div class="logo" onclick="menu()">
            <div class="logo-text"><img src="/feira/ENERGY_TECH/img/aguia.png" width="35px"></div>
        </div>

        <h1>ENERGY TECH</h1>
        <div class="user-menu">
            <button class="user-button" onclick="toggleMenu()">Nome do Usuário ▼</button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="/feira/ENERGY_TECH/login/loginn.php" onclick="logout()">Sair</a>
                <a onclick="ajuda()" >Ajuda</a>
            </div>
            


        </div>
    </header>

    <div class="content">
        <h1 class="txt">MONITORAMENTO</h1>
        <div class="card" onclick="relatorio()" style="background-color: #ffd700;">
            
            <p>RELATORIOS</p>
        </div>
        <div class="blocks">
            <div class="block color-change">
                <img src="src/predio-removebg-preview.png" alt="Bloco A" onclick="Sala()" class="building-icon" style="width: 450px; height: auto;">
                    
                <p>BLOCO A</p>
            </div>
            <div class="block color-change">
                <img src="src/predio-removebg-preview.png" alt="Bloco B" onclick="Sala2()" class="building-icon" style="width: 450px; height: auto;">
                
                <p>BLOCO B</p>
            </div>
            
            </div>
        </div>
    </div>
    <script>
        function toggleMenu() {
            const dropdown = document.getElementById("dropdownMenu");
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
        }

        function logout() {

            alert("Você saiu do sistema.");
        }

        

        
        function Sala(){
            window.location.href = "/feira/ENERGY_TECH/monitoramento/sala.php"
        }
        function Sala2(){
            window.location.href = "/feira/ENERGY_TECH/monitoramento/saladois.php"
        }
        function menu(){
            window.location.href = "/feira/ENERGY_TECH/dashbord_admin/admin.php"
        }
        function relatorio(){
            window.location.href = "/feira/ENERGY_TECH/projeto__/Relatorios.php"
        }
        function ajuda() {
            window.location.href = "/feira/ENERGY_TECH/ajuda/index.php"
        }
        function mostrarNomeUsuario() {
            const nomeUsuario = localStorage.getItem("nomeUsuario");
            if (nomeUsuario) {
                document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
            }
        }

        // Chame a função ao carregar a página
        mostrarNomeUsuario();

        // Alternar cores das divs a cada 10 segundos
        const blocks = document.querySelectorAll('.color-change');
        const colors = ['green','grey', 'orange']; // Defina as classes de cores no CSS
        let colorIndex = 0;


        setInterval(changeBlockColors, 1000); // Muda a cor a cada 10 segundos
    </script>
</body>
</html>
