<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoramento - ENERGY TECH</title>
    <link rel="stylesheet" href="sala_aula.css">
    <link rel="icon" href="/feira/ENERGY_TECH/img/aguia.png" type="image/png">
</head>
<body>
    <header class="navbar">
        <div class="logo" onclick="menu()">
            <div class="logo-text"><img src="/feira/ENERGY_TECH/img/aguia.png" width="35px"></div>
        </div>
        <h1>ENERGY TECH</h1>
        <div class="user-menu">
            <button class="user-button" onclick="toggleMenu()">Nome do Usuário ▼</button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="/feira/ENERGY_TECH/login/loginn.php" onclick="logout()">Sair</a>
                <a onclick="ajuda()">Ajuda</a>
            </div>
        </div>
    </header>

    <div class="content">
        <h2 class="txt">MONITORAMENTO: BLOCO B</h2>
        <select class="seleto" id="blocoSelect" onchange="trocarBloco()">
            <option value="/feira/ENERGY_TECH/monitoramento/saladois.php">BLOCO B</option>
            <option value="/feira/ENERGY_TECH/monitoramento/sala.php">BLOCO A</option>
            <option value="/feira/ENERGY_TECH/projeto__/Relatorios.php">RELATORIO</option>
        </select>

        <div class="blocks">
            <!-- Bloco para a Sala 1 -->
           

            <!-- Bloco para a Sala 3 -->
            <div class="block color-change" id="block3">
                <img src="src/sla_de_aula-removebg-preview.png" alt="Bloco C" class="building-icon" style="width: 150px; height: auto;">
                <p>SALA-03</p>
                <p id="chave3">Carregando...</p>
            </div>

            <!-- Bloco para a Sala 4 -->
            <div class="block color-change" id="block4">
                <img src="src/sla_de_aula-removebg-preview.png" alt="Bloco D" class="building-icon" style="width: 150px; height: auto;">
                <p>SALA-04</p>
                <p id="chave4">Carregando...</p>
            </div>
        </div>
    </div>

    <script>
        function toggleMenu() {
            const dropdown = document.getElementById("dropdownMenu");
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
        }

        function logout() {
            alert("Você saiu do sistema.");
        }

        function menu() {
            window.location.href = "/feira/ENERGY_TECH/dashbord_admin/admin.php";
        }

        function ajuda() {
            window.location.href = "/feira/ENERGY_TECH/ajuda/index.php";
        }

        function trocarBloco() {
            const select = document.getElementById("blocoSelect");
            const blocoUrl = select.value;
            window.location.href = blocoUrl;
        }

        function atualizarChave(idChave, idBloco, dadosChave) {
            const elementoChave = document.getElementById(idChave);
            const blocoDiv = document.getElementById(idBloco);

            const valorChave = String(dadosChave.status);  // Verifique se a chave está ligada ou desligada
            const reservaAtiva = dadosChave.reserva === 'Reservado';  // Verifique se a reserva está ativa

            // Se a chave está **desligada** (valor "1")
            if (valorChave === "1") {
                elementoChave.textContent = "Desligado";
                blocoDiv.style.backgroundColor = "#5b5b5b95";  // Cor cinza para chave desligada
            } 
            // Se a chave está **ligada** (valor "0") e há uma reserva ativa
            else if (valorChave === "0" && reservaAtiva) {
                elementoChave.textContent = "Ligado e Reservado";
                blocoDiv.style.backgroundColor = "green";  // Cor verde para chave ligada com reserva ativa
            } 
            // Se a chave está **ligada** (valor "0") mas não há reserva ativa
            else if(valorChave === "0" && !reservaAtiva) {
                elementoChave.textContent = "Ligado Sem Reserva";
                blocoDiv.style.backgroundColor = "orange";  // Cor laranja para chave ligada sem reserva
            }
        }

        function atualizarDados() {
            fetch('/feira/ENERGY_TECH/monitoramento/dados_atualizados.php')
                .then(response => response.json())
                .then(data => {
                    if (data && !data.error) {
                       
                        atualizarChave("chave3", "block3", data.chave3);
                        atualizarChave("chave4", "block4", data.chave4);
                    } else {
                        mostrarErro();
                    }
                })
                .catch(error => {
                    mostrarErro();
                });
        }

        function mostrarErro() {
            document.getElementById("chave1").textContent = 'Erro ao carregar dados';
            document.getElementById("chave2").textContent = 'Erro ao carregar dados';
            document.getElementById("chave3").textContent = 'Erro ao carregar dados';
            document.getElementById("chave4").textContent = 'Erro ao carregar dados';
            document.getElementById("block1").style.backgroundColor = "#FF0000";
            document.getElementById("block2").style.backgroundColor = "#FF0000";
            document.getElementById("block3").style.backgroundColor = "#FF0000";
            document.getElementById("block4").style.backgroundColor = "#FF0000";
        }

        setInterval(atualizarDados, 1000);

        function mostrarNomeUsuario() {
            const nomeUsuario = localStorage.getItem("nomeUsuario");
            if (nomeUsuario) {
                document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
            }
        }

        mostrarNomeUsuario();
    </script>
</body>
</html>
