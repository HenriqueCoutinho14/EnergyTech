<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Energy Tech</title>
    <link rel="stylesheet" href="./stylee.css">
    <link rel="icon" href="/feira/ENERGY_TECH//img/aguia.png" type="image/png">

</head>

<body>
    <div class="login-container">

        <div class="logo">
            <div class="logo-text"><img src="/feira/ENERGY_TECH//img/aguia.png" width="160px" alt=""></div>
        </div>
        <div class="box_1">
            <h1>ENERGY<br> TECH</h1>



            <form class="loginForm" id="loginForm" action="/feira/ENERGY_TECH//dashbord_admin/admin.php" method="get"
                onsubmit="salvarNomeUsuario()">
                <h2 class="txtt">Faça o Login para entrar no<br> Sistema</h2>
                <div class="input-group">
                    <label for="name">NOME:</label>
                    <input type="text" id="name" name="nome_" required>
                </div>
                <div class="input-group">
                    <label for="password">SENHA:</label>
                    <input type="password" id="password" name="senha_" required>
                </div>
                <button type="submit">ENTRAR</button>
            </form>
        </div>
    </div>
    <script>
        function salvarNomeUsuario() {
            const nome = document.getElementById("name").value;
            localStorage.setItem("nomeUsuario", nome);
        }

    </script>

</body>

</html>
