<?php
include 'C:\xampp\htdocs\feira\ENERGY_TECH\database\banco.php';

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Usuario - ENERGY TECH</title>
  <link rel="stylesheet" href="styless.css">
  <link rel="icon" href="/feira/ENERGY_TECH/img/aguia.png" type="image/png">

</head>

<body>
  <header class="navbar">
    <div class="logo" onclick="menu()">
      <div class="logo-text"><img src="/feira/ENERGY_TECH/img/aguia.png" width="35px"></div>
    </div>

    <h1>ENERGY TECH</h1>
    <div class="user-menu">
      <button class="user-button" onclick="toggleMenu()">Nome do Usuário ▼</button>
      <div id="dropdownMenu" class="dropdown-content">
        <a href="/feira/ENERGY_TECH/login/loginn.php" onclick="logout()">Sair</a>
        <a onclick="ajuda()">Ajuda</a>
      </div>
    </div>
  </header>

  <div id="reservation-screen" class="screen">
    <h2 class="reserva">CADASTRAR USUARIO</h2>
    
  <form class="form" action="\feira\ENERGY_TECH\database\processa_dados.php" method="post">
    <div class="form-row">
        <div class="col">
            <label for="input1">Nome</label>
            <input type="text" name="nome" id=""><br>
        </div><br><br>
        <br><div class="col">
            <label for="input2">Senha</label>
            <input type="password" name="senha" id="">
        </div>
       
        
    </div>

    <button type="submit" class="reserve-button">Cadastrar</button>
</form>

<!-- Tabela Abaixo do Formulário -->
<div class="table-container">
    <table class="table">
        <tr>
            <th>Id</th>
            <th>Nome</th>
            <th>Excluir</th>
        </tr>
        <?php
        $mostra = mostraUsuario();
        foreach($mostra as $i) {
            echo "<tr>
                    <td>".htmlspecialchars($i['idusuario'])."</td>
                    <td>".htmlspecialchars($i['nome'])."</td>
                    <td><a href='?excluir_id=".urlencode($i['idusuario'])."' onclick='return confirm(\"Tem certeza que deseja excluir o usuário?\");'><img src='/feira/ENERGY_TECH/img/excluir.png' width='30px'></a></td>
                  </tr>";
        }
        ?>
    </table>
</div>
  


  <script>
    function toggleMenu() {
      const dropdown = document.getElementById("dropdownMenu");
      dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    }

    function logout() {
      alert("Você saiu do sistema.");
    }
    function ajuda() {
            window.location.href = "/feira/ENERGY_TECH/ajuda/index.php"
        }

    function menu() {
      window.location.href = "/feira/ENERGY_TECH/dashbord_admin/admin.php"
    }
    function mostrarNomeUsuario() {
            const nomeUsuario = localStorage.getItem("nomeUsuario");
            if (nomeUsuario) {
                document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
            }
        }

        // Chame a função ao carregar a página
        mostrarNomeUsuario();
  </script>
</body>

</html>
