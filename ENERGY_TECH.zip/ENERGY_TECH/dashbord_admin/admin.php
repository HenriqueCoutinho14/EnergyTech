<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Energy Tech - Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="/feira/ENERGY_TECH/img/aguia.png" type="image/png">

</head>

<body>
    <header class="navbar">
        <div class="logo">
            <div class="logo-text"><img src="/feira/ENERGY_TECH//img/aguia.png" width="35px"></div>
        </div>

        <h1>ENERGY TECH</h1>
        <div class="user-menu">
            <button class="user-button" onclick="toggleMenu()"></button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="/feira/ENERGY_TECH//login/loginn.php" onclick="logout()">Sair</a>
                <a onclick="ajuda()">Ajuda</a>
            </div>



        </div>
    </header>

    <main class="dashboard">
        <div class="card" onclick="bloco()" style="background-color:   #ffd700;">
            <img src="/feira/ENERGY_TECH//img/monitoramento.png" onclick="" alt="Ícone Monitoramento" class="card-icon">
            <p>MONITORAMENTO</p>
        </div>
        <div class="card" onclick="relatorio()" style="background-color: #ffd700;">
            <img src="/feira/ENERGY_TECH//img/relatorio.png" onclick="" alt="Ícone Monitoramento" class="card-icon">
            <p>RELATORIOS</p>
        </div>

        <div class="card" onclick="reserva()" style="background-color: #00cc44;">
            <img src="/feira/ENERGY_TECH//img/reservar.png" alt="Ícone Reservar Sala" class="card-icon">
            <p>RESERVAR SALA</p>
        </div>
        <div class="card2" onclick="registrar()" style="background-color: #00cc44;">

            <img src="/feira/ENERGY_TECH//img/user.png" alt="Ícone Registrar Usuário" class="card-icon">


            <p>USUARIOS</p>
        </div>
        <div class="card" onclick="consumo()" style="background-color: #ff7c1e;">
            <img src="/feira/ENERGY_TECH//img/consumo.png" alt="Ícone Consumo" class="card-icon">
            <p>CONSUMO</p>
        </div>
        <div class="card" onclick="ajuda()" style="background-color: #ff7c1e;">
            <img src="/feira/ENERGY_TECH//img/help.png" alt="Ícone Consumo" class="card-icon">
            <p>AJUDA</p>
        </div>


    </main>
    <script>
        function toggleMenu() {
            const dropdown = document.getElementById("dropdownMenu");
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
        }

        function logout() {

            alert("Você saiu do sistema.");
        }

        function bloco() {
            window.location.href = "/feira/ENERGY_TECH//monitoramento/index.php"
        }
        function registrar() {
            window.location.href = "/feira/ENERGY_TECH//registra/registra.php"
        }
        function deleta() {
            window.location.href = "/feira/ENERGY_TECH/deleta/index.php"
        }
        function reserva() {
            window.location.href = "/feira/ENERGY_TECH/projeto__/Reserva.php"
        }

        function consumo() {
            window.location.href = "/feira/ENERGY_TECH/consumo/index.php"
        }
        function relatorio() {
            window.location.href = "/feira/ENERGY_TECH/projeto__/Relatorios.php"
        }
        function ajuda() {
            window.location.href = "/feira/ENERGY_TECH/ajuda/index.php"
        }


        function mostrarNomeUsuario() {
            const nomeUsuario = localStorage.getItem("nomeUsuario");
            if (nomeUsuario) {
                document.querySelector(".user-button").textContent = `${nomeUsuario} ▼`;
            }
        }

        // Chame a função ao carregar a página
        mostrarNomeUsuario();



    </script>
</body>

</html>